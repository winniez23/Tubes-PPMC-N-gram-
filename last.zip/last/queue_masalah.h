#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "boolean.h"
#define Nil NULL

typedef struct //struct untuk tabel n-gram
{
	char* key;
	char* value;
}
ngram;

typedef struct node{ //struct untuk menyimpan beberapa value dalam satu key
	char* valueq;
	struct node* next;
} node;

typedef struct { //struct untuk queue
	node* head;
	node* tail;
} Queue;

typedef struct { //struct untuk kata
	char huruf[100];
} kata;

void createEmpty(Queue* Q);
node* Alokasi(char*);
void Push(Queue* Q, char*);
void Pop(Queue* Q, char*);
void Print(Queue*);

void generate (int* banyak_kata,int panjangList,  Queue* Q, ngram* tabel_gram, int* start); //menghasilkan queue yang berisi kata2 yang telah digenerate berdasarkan tabel n-gram
